# Algorithmic Trading Book

2 books and related source codes for algorithmic trading.

- Successful Algorithmic Trading
- Advanced Algorithmic Trading
